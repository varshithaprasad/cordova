//
// Created by David Hedbor on 2021-04-09.
//

#import <Foundation/Foundation.h>

typedef NS_OPTIONS(NSInteger, STSpeedtestOptions) {
    STSpeedtestOptionsDisableLocationService = 1 << 0
};

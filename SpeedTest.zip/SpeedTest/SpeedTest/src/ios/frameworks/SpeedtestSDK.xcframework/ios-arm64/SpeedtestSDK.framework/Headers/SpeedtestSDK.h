//
// Created by David Hedbor on 1/8/20.
//
// SDK Umbrella Header

#import <SpeedtestSDK/SpeedtestSDKConfig-Bridging-Header.h>
#import <SpeedtestSDK/SpeedtestSDKModel-Bridging-Header.h>
#import <SpeedtestSDK/SpeedtestSDKHandler-Bridging-Header.h>
#import <SpeedtestSDK/SpeedtestSDK-Bridging-Header.h>

#import <SpeedtestSDK/SpeedtestSDKVideo-Bridging-Header.h>

#import "STSpeedtestOptions.h"
